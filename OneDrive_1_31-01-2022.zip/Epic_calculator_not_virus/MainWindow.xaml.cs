﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Epic_calculator_not_virus
{
    /// <summary>
    /// Interaktionslogik für MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }


        string imput;
        string lastletter;
        string lul;


        /// </Sonderzeichen>
        private void Reset_Click(object sender, RoutedEventArgs e)
        {
            imput = string.Empty;
            tbEigabe.Text = imput;
        }

        private void zurück_Click(object sender, RoutedEventArgs e)
        {
            if (imput.Length > 0) {
                imput = imput.Remove(imput.Length - 1);
                tbEigabe.Text = imput;
            }
        }

        private void geteiltdurch_Click(object sender, RoutedEventArgs e)
        {
            if (String.Equals(string.Empty, imput))
                
                lastletter = imput.Substring(imput.Length - 1);
                Console.WriteLine(lastletter);
                if (String.Equals(lastletter, "/"))
                {
                    lul = "hir ist schon geteiltdurch :(";
                    Console.WriteLine(lul);
                }
                else
                {
                    imput = imput + '/';
                    tbEigabe.Text = imput;
                }
            }

        }
    }

        private void X_Click(object sender, RoutedEventArgs e)
        {
            lastletter = imput.Substring(imput.Length - 1);
            Console.WriteLine(lastletter);
            if (String.Equals(lastletter, "*"))
            {
                lul = "hir ist schon mal :(";
                Console.WriteLine(lul);
            }
            else
            {
                imput = imput + '*';
                tbEigabe.Text = imput;
            }
            }

        

        private void minus_Click(object sender, RoutedEventArgs e)
        {
            lastletter = imput.Substring(imput.Length - 1);
            Console.WriteLine(lastletter);
            if (String.Equals(lastletter, "-"))
            {
                lul = "hir ist schon minus :(";
                Console.WriteLine(lul);
            }
            else
            {
                imput = imput + '-';
                tbEigabe.Text = imput;
            }

        }

        private void plus_Click(object sender, RoutedEventArgs e)
        {
            lastletter = imput.Substring(imput.Length - 1);
            Console.WriteLine(lastletter);
            if (String.Equals(lastletter, "+"))
            {
                lul = "hir ist schon plus :(";
                Console.WriteLine(lul);
            }
            else
            {
                imput = imput + '+';
                tbEigabe.Text = imput;
            }


        }

        private void istgleich_Click(object sender, RoutedEventArgs e)
        {

        }

        private void komma_Click(object sender, RoutedEventArgs e)
        {
            lastletter = imput.Substring(imput.Length - 1);
            Console.WriteLine(lastletter);
            if (String.Equals(lastletter, "."))
            {
                lul = "hir ist schon mal :(";
                Console.WriteLine(lul);
            }
            else
            {
                imput = imput + '.';
                tbEigabe.Text = imput;
            }


        }

        private void vorzeichen_Click(object sender, RoutedEventArgs e)
        {

        }

        /// </Zahlen>

        private void null_Click(object sender, RoutedEventArgs e)
        {
            imput = imput + '0';
            tbEigabe.Text = imput;

        }

        private void eins_Click(object sender, RoutedEventArgs e)
        {
            imput = imput + '1';
            tbEigabe.Text = imput;
        }

        private void zwei_Click(object sender, RoutedEventArgs e)
        {
            imput = imput + '2';
            tbEigabe.Text = imput;
        }

        private void drei_Click(object sender, RoutedEventArgs e)
        {
            imput = imput + '3';
            tbEigabe.Text = imput;
        }

        private void vier_Click(object sender, RoutedEventArgs e)
        {
            imput = imput + '4';
            tbEigabe.Text = imput;
        }

        private void fünf_Click(object sender, RoutedEventArgs e)
        {
            imput = imput + '5';
            tbEigabe.Text = imput;
        }

        private void sechs_Click(object sender, RoutedEventArgs e)
        {
            imput = imput + '6';
            tbEigabe.Text = imput;
        }

        private void sieben_Click(object sender, RoutedEventArgs e)
        {
            imput = imput + '7';
            tbEigabe.Text = imput;
        }

        private void acht_Click(object sender, RoutedEventArgs e)
        {
            imput = imput + '8';
            tbEigabe.Text = imput;
        }

        private void neun_Click(object sender, RoutedEventArgs e)
        {
            imput = imput + '9';
            tbEigabe.Text = imput;
        }

        
        


    }
}
